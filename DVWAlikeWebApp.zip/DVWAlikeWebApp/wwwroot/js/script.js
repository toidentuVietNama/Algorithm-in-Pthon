$(document).ready(function () {
    $('.vulnerability-link').click(function () {
        var vulnerability = $(this).data('vulnerability');
        loadVulnerability(vulnerability);
    });
});

function loadVulnerability(vulnerability) {
    $.ajax({
        url: `/Vulnerabilities/${vulnerability}`,
        type: 'GET',
        success: function (data) {
            $('#vulnerability-content').html(data);
        },
        error: function () {
            $('#vulnerability-content').html('Error loading vulnerability page.');
        }
    });
}

function loadVulnerability(vulnerability) {
    if (vulnerability === "XSS") {
        var xssContent = `
            <h2>Cross-Site Scripting (XSS)</h2>
            <input type="text" id="inputData" placeholder="Nhập dữ liệu">
	    <button onclick="displayInput()">In ra màn hình</button>
	    <div id="displayData"></div>
	    <div id="buttons-container"></div>
	   <div id="buttons-container">
		  <button id="button1" class="buttons-container" onclick="showCode(1)">View Resource</button>
		  <button id="button2" class="buttons-container" onclick="showCode(2)">View Help</button>
		  <button id="button3" class="buttons-container" onclick="showCode(3)">Update</button>
		</div>
		<div id="code-content"></div>
        `;
        $('#vulnerability-content').html(xssContent);
        
    }
}

 function displayInput() {
    var inputData = document.getElementById('inputData').value;
    document.getElementById('displayData').innerHTML = inputData;
  }
function sanitizeHTML(str) {
    var temp = document.createElement('div');
    temp.innerText = str;
    return temp.innerHTML;
}


function showCode(codeNumber) {
  var codeContent = document.getElementById('code-content');
  if (codeNumber === 1) {
    codeContent.textContent = 
  ` function displayInput() {
    var inputData = document.getElementById('inputData').value;
    document.getElementById('displayData').innerHTML = inputData;
  }
function sanitizeHTML(str) {
    var temp = document.createElement('div');
    temp.innerText = str;
    return temp.innerHTML;`;
  } else if (codeNumber === 2) {
    codeContent.textContent = 'Đoạn mã mẫu số 2';
  } else if (codeNumber === 3) {
    codeContent.textContent = 'Đoạn mã mẫu số 3';
  } else {
    codeContent.textContent = 'Không có mã mẫu cho lựa chọn này.';
  }
}
